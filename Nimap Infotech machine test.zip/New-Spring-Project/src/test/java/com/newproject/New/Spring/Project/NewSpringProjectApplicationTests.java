package com.newproject.New.Spring.Project;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class NewSpringProjectApplicationTests {

	@Test
	void contextLoads() {
	}

}
